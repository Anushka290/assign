from django.contrib import admin

from .models import book

admin.site.register([book])